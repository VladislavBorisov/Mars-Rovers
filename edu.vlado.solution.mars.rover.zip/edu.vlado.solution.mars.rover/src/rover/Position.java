package rover;

public class Position implements PositionIF {

	private Axis x = null;
	private Axis y = null;
	private Direction direction = null;

	public Position(Axis x, Axis y, Direction direction) {
		if (x == null || y == null || direction == null) {
			throw new IllegalArgumentException(
					"Position's attributes can't be null");
		}
		this.direction = direction;
		this.x = x;
		this.y = y;
	}

	protected void setDirectionRight() {
		direction = direction.right();
	}

	protected void setDirectionLeft() {
		direction = direction.left();
	}

	public Axis getX() {
		return x;
	}

	public Axis getY() {
		return y;
	}

	public Direction getDirection() {
		return direction;
	}

	@Override
	public String toString() {
		return getX().getAxis() + " : " + getY().getAxis() + " : "
				+ getDirection().name();
	}

}
