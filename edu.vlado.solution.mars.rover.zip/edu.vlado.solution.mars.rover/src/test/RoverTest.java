package test;

import rover.PositionIF;
import rover.Rover;
import rover.Rover.Command;

public class RoverTest {
	public static void main(String[] args) {
		// Test 1 RFLFFRF
		Rover rover1 = new Rover(new PositionIF.Axis(1),
				new PositionIF.Axis(2), rover.PositionIF.Direction.WEST);
		rover1.processCommands(new Command[] { Command.RIGHT, Command.FORWARD,
				Command.LEFT, Command.FORWARD, Command.FORWARD,
				Command.FORWARD, Command.RIGHT, Command.FORWARD });
		System.out.println(rover1.getPosition());

	}
}
